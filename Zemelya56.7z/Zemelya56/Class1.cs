using System;

namespace Zemelya56
{
    public class Class1
    {
    }
}
